Die Dateien in diesem Archiv sind Teil des "Referenzkorpus Mittelhochdeutsch".

Das Referenzkorpus Mittelhochdeutsch ist lizenziert unter einer Creative Commons
Namensnennung - Weitergabe unter gleichen Bedingungen 4.0 International
Lizenz (https://creativecommons.org/licenses/by-sa/4.0/).

Bitte zitieren Sie das Korpus in Ihren Arbeiten wie folgt:

Klein, Thomas; Wegera, Klaus-Peter; Dipper, Stefanie; Wich-Reif, Claudia
(2016). Referenzkorpus Mittelhochdeutsch (1050–1350), Version 1.0,
https://www.linguistics.ruhr-uni-bochum.de/rem/. ISLRN 332-536-136-099-5.

- - -

The files contained in this archive are part of the "Reference Corpus of Middle
High German".

The Reference Corpus of Middle High German is licensed under a Creative Commons
Attribution-ShareAlike 4.0 International license
(https://creativecommons.org/licenses/by-sa/4.0/).

If you use this corpus in your work, please cite it as follows:

Klein, Thomas; Wegera, Klaus-Peter; Dipper, Stefanie; Wich-Reif, Claudia
(2016). Referenzkorpus Mittelhochdeutsch (1050–1350), Version 1.0,
https://www.linguistics.ruhr-uni-bochum.de/rem/. ISLRN 332-536-136-099-5.
